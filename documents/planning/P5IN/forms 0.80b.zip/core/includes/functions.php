<?php

/**
 * Project specific functions
 */

	// None!

// EOF