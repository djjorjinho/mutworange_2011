<?php

define('PATH_LIBRARY', dirname(__FILE__) . '/library');
set_include_path(get_include_path() . PATH_SEPARATOR . PATH_LIBRARY . PATH_SEPARATOR);
// config & functions
require_once 'core/includes/config.php';
require_once 'core/includes/functions.php';

// Include Plonk & PlonkWebsite
require_once 'plonk/plonk.php';
require_once 'plonk/website/website.php';
require_once 'plonk/filter/filter.php';
require_once './library/validation/validation.php';
require_once './library/phpmailer/class.phpmailer.php';



//echo file_get_contents('./modules/learnagr_ch/layout/learnagrch.tpl');


// ... require other classes if needed.
// Disable Magic Quotes
PlonkFilter::disableMagicQuotes();

// Gentlemen, start your engines!
try {
	
	// This is the real deal here :-)
	$website = new PlonkWebsite(
		array('home','trrec','formselect','learnagr_ch','acom_reg','abroad_stay')
	);
	
} catch (Exception $e) { 	// Ooops, somehing went wrong ...
	if (defined('DEBUG') && (DEBUG === true))
	{			
		echo '<h1>Exception Occured</h1><pre>';
		throw $e;
	} else exit('There was an error with processing your request - Please retry.');
}

// EOF - Yes, that's it! :-)