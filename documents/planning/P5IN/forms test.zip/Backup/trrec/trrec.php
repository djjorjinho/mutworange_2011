<?php

class trrecController extends PlonkController {

    protected $views = array('actionSelect', 'vsended', 'select', 'main', 'success', 'mainrecords','confirm','error');
    protected $actions = array('search', 'prev', 'next', 'selectuser', 'postdata','send','resend');
    private $errors = ''; // set the errors array to empty, by default
    private $fields = array(); // stores the field values
   

/* For Using this PlonkSession::get('id'); must be an id of the coordinator
 * Transcript of records returns students that is not in Grades table and
 * student hostCoordinatorId == PlonkSession::get('id'); 
 */
    
    
    public function showactionselect() {
        //Var For selecting the First 20 recs


        PlonkSession::set('listNumRec', '0');
        PlonkSession::set('listNum', '0');
        PlonkSession::set('search', '');

        $this->mainTpl->assign('pageMeta', '<script src=""></script>');
        $this->mainTpl->assign('pageTitle', "Select Action");
        $this->mainTpl->assign('pageCSS', '');
    }

    /* Transcript Of Records REGISTER */

    public function showselect() {
        $this->mainTpl->assign('pageMeta', '<script src="core/js/jquery-1.5.1.min.js" type="text/javascript"></script><script src="core/js/sorttable.js" type="text/javascript"></script>');
        $this->mainTpl->assign('pageTitle', "Select Student");
        $this->mainTpl->assign('pageCSS', '<link rel="stylesheet" href="core/css/validationEngine.jquery.css" type="text/css"/>');
        $this->pageTpl->assign('errorString', $this->errors);
        $this->errors = '';
        //Set the Position to Select Student for search Engine
        PlonkSession::set('posSearch', 'forMain');



        //Generates Student List

        $recNums = PlonkSession::get('listNum');
        $search = PlonkSession::get('search');
        PlonkSession::set('selUserForMain', '');


        $studentsLName = trrecDB::getStudentList($recNums);
        if (!empty($search)) {
            $studentsLName = PlonkSession::get('search');
            PlonkSession::set('search', '');
        }
        $this->pageTpl->setIteration('iStudentsList');
        foreach ($studentsLName as $key => $value) {
            $this->pageTpl->assignIteration('studentsList', '<tr>
                <td> ' . $value['userId'] . '</td><td> ' . $value['firstName'] .
                    '</td><td> ' . $value['familyName'] . '</td>
                        <td><form  method="post">
                        <input type="hidden" name="stn" value="' . $value['userId'] . '" />
                            <input type="hidden" name="formAction" id="formLogin" value="doSelectUser" />
                            <input class="nxtBtn" type="submit" value=">"/></form></td></tr>');
            $this->pageTpl->refillIteration('iStudentsList');
        }
        $this->pageTpl->parseIteration('iStudentsList');
    }

    public function showmain() {
        $pos = PlonkSession::get('posSearch');
        $name  = PlonkSession::get('selUserForMain');
        

        if (($pos != 'register') || (empty($name))) {
            PlonkWebsite::redirect($_SERVER['PHP_SELF'] . '?' . PlonkWebsite::$moduleKey . '=trrec&' . PlonkWebsite::$viewKey . '=select');
        }

        PlonkSession::set('posSearch', '');
        PlonkSession::set('selUserForMain','');
        
        $this->mainTpl->assign('pageMeta', '<script src="core/js/jquery-1.5.1.min.js" type="text/javascript"></script>
        <script src="core/js/jquery.validationEngine-en.js" type="text/javascript" charset="utf-8"> </script>
        <script src="core/js/jquery.validationEngine.js" type="text/javascript" charset="utf-8"></script>
        <script src="core/js/custom.js" type="text/javascript" charset="utf-8"> </script>');
        $this->pageTpl->assign('errorString', $this->errors);
                        $this->pageTpl->assign('back', 'index.php?module=trrec&view=select');

        $this->mainTpl->assign('pageTitle', "TranScript Of Records");
        $this->mainTpl->assign('pageCSS', '<link rel="stylesheet" href="core/css/validationEngine.jquery.css" type="text/css"/>');
        $this->pageTpl->assign('value', '');
        $this->errors = null;


        $this->getDBdata('reg', $name);
    }

    public function showconfirm(){
        
        $name = PlonkSession::get('selUserForRec');
        PlonkSession::set('selUserForRec', '');
        if ((PlonkSession::get('posSearch') != 'conf') || (empty($name))) {
            PlonkWebsite::redirect($_SERVER['PHP_SELF'] . '?' . PlonkWebsite::$moduleKey . '=trrec&' . PlonkWebsite::$viewKey . '=select');
        }
        
        $this->mainTpl->assign('pageMeta', '');
        $this->pageTpl->assign('errorString', $this->errors);
        $this->mainTpl->assign('pageTitle', "Transcript Of Records");
        //assign pageSpecific CSS
        $this->mainTpl->assign('pageCSS', '');
        $this->pageTpl->assign('value', '');
        $this->errors = null;
        
        
        $stRec = trrecDB::getRecords($name);
        $this->getDBdata('viewRec', $name);
        $this->pageTpl->setIteration('iStudentRec');
        $i = 0;
        while (isset($stRec[$i]['courseCode'])) {
            $this->pageTpl->assignIteration('studentRec', '<tr><td> ' . $stRec[$i]['courseCode'] . '</td><td> ' . $stRec[$i]['courseName'] . '</td><td> ' . $stRec[$i]['ectsCredits'] . '</td><td> ' . $stRec[$i]['courseDuration'] . '</td><td> ' . $stRec[$i]['localGrade'] . '</td><td> ' . $stRec[$i]['ectsGrade'] . '</td></tr>');
            $this->pageTpl->refillIteration('iStudentRec');
            $i++;
        }
        $this->pageTpl->parseIteration('iStudentRec');
            
          
          $this->doSend($this->pageTpl->getContent());
    
    }
    
    public function doSend($form) {
        $return = trrecDB::SubmitTranscript($form);
        
        if ($return == '1') {
            PlonkSession::set('posSearch', 'suc');
            PlonkWebsite::redirect($_SERVER['PHP_SELF'] . '?' . PlonkWebsite::$moduleKey . '=trrec&' . PlonkWebsite::$viewKey . '=success');
        } else {
            PlonkSession::set('posSearch', 'fail');
            PlonkWebsite::redirect($_SERVER['PHP_SELF'] . '?' . PlonkWebsite::$moduleKey . '=trrec&' . PlonkWebsite::$viewKey . '=error');
        }
    }
    
    public function doResend (){
        PlonkSession::set('selUserForRec', $_POST['num']);
        PlonkSession::set('posSearch', 'conf');
          
            PlonkWebsite::redirect($_SERVER['PHP_SELF'] . '?' . PlonkWebsite::$moduleKey . '=trrec&' . PlonkWebsite::$viewKey . '=confirm');
        
    }
    
    public function showsuccess() {
                if (PlonkSession::get('posSearch') != "suc") {
            PlonkWebsite::redirect($_SERVER['PHP_SELF'] . '?' . PlonkWebsite::$moduleKey . '=formselect&' . PlonkWebsite::$viewKey . '=main');
        }
        PlonkSession::set('posSearch', '');
        $this->mainTpl->assign('pageCSS', '');
        $this->mainTpl->assign('pageMeta', '');
        $this->mainTpl->assign('pageTitle', 'Application Success');
        $this->pageTpl->assign('next', 'index.php?module=formselect&view=main');
        

    }
    
    public function showerror() {
        if (PlonkSession::get('posSearch') != "fail") {
            PlonkWebsite::redirect($_SERVER['PHP_SELF'] . '?' . PlonkWebsite::$moduleKey . '=formselect&' . PlonkWebsite::$viewKey . '=main');
        }

        $this->mainTpl->assign('pageCSS', '');
        $this->mainTpl->assign('pageMeta', '');
        $this->mainTpl->assign('pageTitle', 'Application Failed');
        $this->pageTpl->assign('next', 'index.php?module=formselect&view=main');
    }

    public function doPostdata() {

        $i = 1;
        $rules = array();
        $array = array();
        $errors = array();


        foreach ($_POST AS $key => $value) {

            if (stristr($key, 'coursetitle')) {

                $check = $_POST['coursetitle' . $i];
                if ((in_array($check, $array)) && ($i != 1)) {

                    $double = 'You have Dublicate Courses Selected';
                    $er = '1';
                }
                $array[] = $_POST['coursetitle' . $i];


                $rules[] = "required," . $key . ",Course Title " . $i . " is required.";
                $rules[] = "required,locGrade" . $i . ",Local Grade " . $i . " is required.";
                $rules[] = "required,ecGrade" . $i . ",ECTS Grade " . $i . " is required.";



                $this->fields[] = 'coursetitle' . $i;
                $this->fields[] = 'locGrade' . $i;
                $this->fields[] = 'ecGrade' . $i;

                $i++;
            }
                        
               
        
        }

        foreach ($_POST AS $key => $value) {
            $errors = validateFields($_POST, $rules);
        }
        if (!empty($errors)) {
            $er = '1';
        }


        $name = $_POST['num'];
        $dtDubl = trrecDB::checkDubl($name);
        if (($dtDubl == "Dub" ) || (empty($name))) {
            $dbDub = 'Entry Exists in Database';
            $er = '1';
        }


        if (!empty($er)) {
            $errorString = '<div style="height:90px; background: #f0d3d3; text-align: center; font-size: medium;"> ';

            $errorString .= '<p><p>There was an error processing the form.</p>';
            if (!empty($dbDub)) {
                $errorString .="<p>" . $dbDub . "</p>";
            }
            if (!empty($double)) {
                $errorString .="<p>" . $double . "</p>";
            }
            if (!empty($errors)) {
                $errorString .= '<p>Please fill all fields marked with *</p>';
                $errorString .= '</div><div>';

                $errorString .= '<ul>';
                foreach ($errors as $key) {
                    $errorString .= "<li>$key</li>";
                }
                $errorString .= '</ul>';
            }

            $errorString .= '</div>';
            $er = '';
            // display the previous form */
            $this->errors = $errorString;
            $this->fields = $_POST;
            PlonkSession::set('selUserForMain', $name);
            PlonkSession::set('posSearch', 'register');
        } else {



            
            trrecDB::formAp($name);
            PlonkSession::set('posSearch', 'conf');
            PlonkSession::set('selUserForRec', $name);
            PlonkWebsite::redirect($_SERVER['PHP_SELF'] . '?' . PlonkWebsite::$moduleKey . '=trrec&' . PlonkWebsite::$viewKey . '=confirm');
        }
    }

    /* Transcript Of Records VIEW */

    public function showvsended() {
        $this->mainTpl->assign('pageMeta', '<script src="core/js/jquery-1.5.1.min.js" type="text/javascript"></script><script src="core/js/sorttable.js" type="text/javascript"></script>');
        $this->mainTpl->assign('pageTitle', "Sended TranScripts Of Records");
        $this->mainTpl->assign('pageCSS', '');
        $this->pageTpl->assign('errorString', $this->errors);
        PlonkSession::set('posSearch', 'forMainRec');

        //Generates Student List
        $recNums = PlonkSession::get('listNumRec');
        $search = PlonkSession::get('search');
        PlonkSession::set('seluser', '');

        $studentsLName = trrecDB::getStudentRecords($recNums);
        if (!empty($search)) {
            $studentsLName = PlonkSession::get('search');
            PlonkSession::set('search', '');
        }
        $this->pageTpl->setIteration('iRecords');
        foreach ($studentsLName as $key => $value) {
            $this->pageTpl->assignIteration('records', '<tr><td> ' . $value['userId'] . '</td><td> ' . $value['firstName'] . '</td><td> ' . $value['familyName'] . '</td><td><form  method="post"><input type="hidden" name="stn" value="' . $value['userId'] . '" /><input type="hidden" name="formAction" id="formLogin" value="doSelectUser" /><input class="nxtBtn" type="submit" value=">"/></form></td></tr>');
            $this->pageTpl->refillIteration('iRecords');
        }
        $this->pageTpl->parseIteration('iRecords');
    }

    public function showmainrecords() {
                $pos = PlonkSession::get('posSearch');
$name = PlonkSession::get('selUserForRec');        

        if (($pos != 'forMainRec') || (empty($name))) {
            PlonkWebsite::redirect($_SERVER['PHP_SELF'] . '?' . PlonkWebsite::$moduleKey . '=trrec&' . PlonkWebsite::$viewKey . '=vsended');
        }
        $this->mainTpl->assign('pageMeta', '');
        $this->pageTpl->assign('errorString', $this->errors);
        $this->mainTpl->assign('pageTitle', "Trancip Of Records");
        //assign pageSpecific CSS
        $this->mainTpl->assign('pageCSS', '');
        $this->pageTpl->assign('value', '');
        $this->errors = null;
        
        PlonkSession::set('selUserForRec','');
        $this->pageTpl->assign('num', $name);
        $stRec = trrecDB::getRecords($name);
        $this->getDBdata('viewRec', $name);
        $this->pageTpl->setIteration('iStudentRec');
        $i = 0;
        while (isset($stRec[$i]['courseCode'])) {
            $this->pageTpl->assignIteration('studentRec', '<tr><td> ' . $stRec[$i]['courseCode'] . '</td><td> ' . $stRec[$i]['courseName'] . '</td><td> ' . $stRec[$i]['ectsCredits'] . '</td><td> ' . $stRec[$i]['courseDuration'] . '</td><td> ' . $stRec[$i]['localGrade'] . '</td><td> ' . $stRec[$i]['ectsGrade'] . '</td></tr>');
            $this->pageTpl->refillIteration('iStudentRec');
            $i++;
        }
        $this->pageTpl->parseIteration('iStudentRec');
        
  
    }

    /* Transcript Of Records Common Actions (VIEW-REGISTER)*/

    public function doSelectUser() {
        $pos = PlonkSession::get('posSearch');
        if ($pos == 'forMain') {
            PlonkSession::set("selUserForMain", $_POST["stn"]);
            PlonkSession::set('posSearch', 'register');
            PlonkWebsite::redirect($_SERVER['PHP_SELF'] . '?' . PlonkWebsite::$moduleKey . '=trrec&' . PlonkWebsite::$viewKey . '=main');
        }

        if ($pos == 'forMainRec') {
            PlonkSession::set("selUserForRec", $_POST["stn"]);
            PlonkWebsite::redirect($_SERVER['PHP_SELF'] . '?' . PlonkWebsite::$moduleKey . '=trrec&' . PlonkWebsite::$viewKey . '=mainrecords');
        }
    }

    public function getDBdata($act, $name) {


        $query = trrecDB::getStudentInfo($name);


        foreach ($query as $key => $value) {
            $this->pageTpl->assign('stFirstName', $value['firstName']);
            $this->pageTpl->assign('stLastName', $value['familyName']);

            $this->pageTpl->assign('stGender', $value['sex'] > 0 ? 'Male' : 'Female');
            $this->pageTpl->assign('stDtBirh', $value['birthDate']);
            $this->pageTpl->assign('stPlBirh', $value['birthPlace']);
            $this->pageTpl->assign('stMatrDate', $value['tel']);
            $this->pageTpl->assign('stMatrNum', $value['email']);
            $this->pageTpl->assign('stMail', $value['email']);

            $query2 = trrecDB::getCoordInfo($query[0]['hostCoordinatorId']);
            foreach ($query2 as $key => $value) {
                $this->pageTpl->assign('seCorName', $value['familyName'].'&nbsp;'.$value['firstName']);
                $this->pageTpl->assign('seCorMail', $value['email']);
                $this->pageTpl->assign('seCorTel', $value['tel']);
                $this->pageTpl->assign('seCorFax', $value['fax']);
            }

            $query2 = trrecDB::getCoordInfo($query[0]['homeCoordinatorId']);
            foreach ($query2 as $key => $value) {
                $this->pageTpl->assign('reCorName', $value['familyName'].'&nbsp;'.$value['firstName']);
                $this->pageTpl->assign('reCorMail', $value['email']);
                $this->pageTpl->assign('reCorTel', $value['tel']);

                $this->pageTpl->assign('reCorFax', $value['fax']);
            }

            $query2 = trrecDB::getInstInfo($query[0]['homeInstitutionId']);
            foreach ($query2 as $key => $value) {
                $this->pageTpl->assign('reInName', $value['instName']);

                //     $this->pageTpl->assign('reCorFax', $value['reCorFax']);*/
            }
            $query2 = trrecDB::getInstInfo($query[0]['hostInstitutionId']);
            foreach ($query2 as $key => $value) {
                $this->pageTpl->assign('seInName', $value['instName']);
            }


            if ($act == "reg") {
                $cour = trrecDB::getInstCourses($query[0]['hostInstitutionId']);


                $this->pageTpl->setIteration('iCourses');
                foreach ($cour as $key => $value) {
                    $this->pageTpl->assignIteration('courses', '<option value="' . $value['courseId'] . '" name="' . $value['ectsCredits'] . '">' . $value['courseCode'] . '&nbsp;&nbsp;&nbsp;&nbsp;' . $value['courseName'] . '</option>');
                    $this->pageTpl->refillIteration('iCourses');
                }
                $this->pageTpl->parseIteration('iCourses');
                $this->pageTpl->assign('num', $name);
            }


        }
    }

    public function doNext() {

        $x = PlonkSession::get('listNum');
        $x+=20;
        $pos = PlonkSession::get('posSearch');

        if ($pos == 'forMain') {
            $recNums = trrecDB::getStudentList($x);
            if (empty($recNums)) {
                PlonkWebsite::redirect($_SERVER['PHP_SELF'] . '?' . PlonkWebsite::$moduleKey . '=trrec&' . PlonkWebsite::$viewKey . '=select');
            }

            PlonkSession::set('listNum', $x);
            PlonkWebsite::redirect($_SERVER['PHP_SELF'] . '?' . PlonkWebsite::$moduleKey . '=trrec&' . PlonkWebsite::$viewKey . '=select');
        }
        $x = PlonkSession::get('listNumRec');
        $x+=20;

        if ($pos == 'forMainRec') {
            $recNums = trrecDB::getStudentRecords($x);
            if (empty($recNums)) {
                PlonkWebsite::redirect($_SERVER['PHP_SELF'] . '?' . PlonkWebsite::$moduleKey . '=trrec&' . PlonkWebsite::$viewKey . '=vsended');
            }

            PlonkSession::set('listNumRec', $x);
            PlonkWebsite::redirect($_SERVER['PHP_SELF'] . '?' . PlonkWebsite::$moduleKey . '=trrec&' . PlonkWebsite::$viewKey . '=vsended');
        }
    }

    public function doPrev() {
        $pos = PlonkSession::get('posSearch');

        $x = PlonkSession::get('listNum');
        if ($x != '0') {
            $x-=20;
        }

        if ($pos == 'forMain') {
            PlonkSession::set('listNum', $x);
            PlonkWebsite::redirect($_SERVER['PHP_SELF'] . '?' . PlonkWebsite::$moduleKey . '=trrec&' . PlonkWebsite::$viewKey . '=select');
        }
        if ($pos == 'forMainRec') {
            PlonkSession::set('listNumRec', $x);
            PlonkWebsite::redirect($_SERVER['PHP_SELF'] . '?' . PlonkWebsite::$moduleKey . '=trrec&' . PlonkWebsite::$viewKey . '=vsended');
        }
    }

    public function doSearch() {
        $pos = PlonkSession::get('posSearch');
        if (!empty($_POST['Search'])) {
            if ($pos == 'forMain') {
                $studentsLName = trrecDB::getSearch($_POST['Search'], $_POST['selection'], 'register');
                PlonkSession::set('search', $studentsLName);
            }
            if ($pos == 'forMainRec') {
                $studentsLName = trrecDB::getSearch($_POST['Search'], $_POST['selection'], 'records');
                PlonkSession::set('search', $studentsLName);
            }
        }
    }

}