<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class abroad_stayController extends PlonkController {

    protected $views = array(
        'cert_ar', 'actionselect', 'select'
    );
    protected $actions = array(
        'submit', 'selectuser', 'selectaction'
    );
    protected $variables = array(
        'hostInstitution', 'dateArrival', 'dateDeparture', 'student'
    );
    private $errors = '';
    private $student = '';
    private $x = '1';




    /* First Step : Select User From List */

    public function showselect() {
        $this->mainTpl->assign('pageMeta', '<script src="core/js/sorttable.js" type="text/javascript"></script>');
        $this->mainTpl->assign('pageTitle', "Select Student");
        $this->mainTpl->assign('pageCSS', '');
        $this->pageTpl->assign('errorString', $this->errors);
        $this->errors = '';
        //Set the Position to Select Student for search Engine
        PlonkSession::set('posSearch', 'abroadStay');
        ////Generates Student List

        $recNums = PlonkSession::get('listNum');
        $search = PlonkSession::get('search');
        PlonkSession::set('selUserForMain', '');


        $studentsLName = abroad_stayDB::getStudentList($recNums);
        if (!empty($search)) {
            $studentsLName = PlonkSession::get('search');
            PlonkSession::set('search', '');
        }
        $this->pageTpl->setIteration('iStudentsList');
        foreach ($studentsLName as $key => $value) {
            $this->pageTpl->assignIteration('studentsList', '<tr>
                <td> ' . $value['userId'] . '</td><td> ' . $value['firstName'] .
                    '</td><td> ' . $value['familyName'] . '</td>
                        <td><form  method="post">
                        <input type="hidden" name="stn" value="' . $value['userId'] . '" />
                            <input type="hidden" name="formAction" id="formLogin" value="doSelectUser" />
                            <input class="nxtBtn" type="submit" value=">"/></form></td></tr>');
            $this->pageTpl->refillIteration('iStudentsList');
        }
        $this->pageTpl->parseIteration('iStudentsList');
    }

    public function doNext() {

        $x = PlonkSession::get('listNum');
        $x+=20;
        $pos = PlonkSession::get('posSearch');

        if ($pos == 'forMain') {
            $recNums = trrecDB::getStudentList($x);
            if (empty($recNums)) {
                PlonkWebsite::redirect($_SERVER['PHP_SELF'] . '?' . PlonkWebsite::$moduleKey . '=trrec&' . PlonkWebsite::$viewKey . '=select');
            }

            PlonkSession::set('listNum', $x);
            PlonkWebsite::redirect($_SERVER['PHP_SELF'] . '?' . PlonkWebsite::$moduleKey . '=trrec&' . PlonkWebsite::$viewKey . '=select');
        }
    }

    public function doPrev() {
        $pos = PlonkSession::get('posSearch');

        $x = PlonkSession::get('listNum');
        if ($x != '0') {
            $x-=20;
        }

        if ($pos == 'forMain') {
            PlonkSession::set('listNum', $x);
            PlonkWebsite::redirect($_SERVER['PHP_SELF'] . '?' . PlonkWebsite::$moduleKey . '=trrec&' . PlonkWebsite::$viewKey . '=select');
        }
    }

    public function doSearch() {
        $pos = PlonkSession::get('posSearch');
        if (!empty($_POST['Search'])) {
            if ($pos == 'forMain') {
                $studentsLName = trrecDB::getSearch($_POST['Search'], $_POST['selection'], 'register');
                PlonkSession::set('search', $studentsLName);
            }
        }
    }

    public function doSelectUser() {
        $pos = PlonkSession::get('posSearch');

        if ($pos == 'abroadStay') {
            PlonkSession::set("selUserAbroad", $_POST["stn"]);
            PlonkSession::set('posSearch', 'asAction');
            PlonkWebsite::redirect($_SERVER['PHP_SELF'] . '?' . PlonkWebsite::$moduleKey . '=abroad_stay&' . PlonkWebsite::$viewKey . '=actionselect');
            
        }
    }

    /* ENDS HERE */



    /* Second Step : Select the Certificate to Provide */

    public function showActionselect() {
        
        $this->student = PlonkSession::get('selUserAbroad');
        PlonkSession::set('selUserAbroad','');
        $this->mainTpl->assign('pageMeta', '<script src="core/js/jquery-1.5.1.min.js" type="text/javascript"></script>
        <script src="core/js/jquery.validationEngine-en.js" type="text/javascript" charset="utf-8"> </script>
        <script src="core/js/jquery.validationEngine.js" type="text/javascript" charset="utf-8"></script>
        <script src="core/js/custom.js" type="text/javascript" charset="utf-8"> </script>');
        $this->mainTpl->assign('pageCSS', '<link rel="stylesheet" href="core/css/validationEngine.jquery.css" type="text/css"/>');
        $this->mainTpl->assign('pageCSS', '');
        $this->pageTpl->assign('student', $this->student);
        $this->pageTpl->assign('seluser', $this->student);
        $this->getDBdata($this->student);

        if ($this->x == '1') {
            $this->pageTpl->assign('form', 'Date of Arrival');
            $this->pageTpl->assign('field', '<div class="TRdiv"><label for="date">Date (yyyy-mm-dd) :  </label><input type="text" name="date"  id="date" class="validate[required,custom[date]] text-input"  /></div>');
        }

        if ($this->x == '2') {
            $this->pageTpl->assign('form', 'Date of Departure');
            $this->pageTpl->assign('field', '<div class="TRdiv"><label for="date">Date (yyyy-mm-dd) :  </label><input type="text" name="dateDep"  id="dateDep" class="validate[required,custom[date]] text-input"  /></div>');
        }

        if ($this->x == '3') {
            $this->pageTpl->assign('form', 'Staying Period');
            $this->pageTpl->assign('field', '<div class="TRdiv"><label for="toDate">From (yyyy-mm-dd) : </label><input type="text" name="fromDate"  id="fromDate" class="validate[required,custom[date]] text-input"  /></div>
                <div class="TRdiv"><label for="toDate">&nbsp;To (yyyy-mm-dd) : </label><input type="text" name="toDate"  id="toDate" class="validate[required,custom[date]] text-input"  /></div>');
        }
    }

    public function doSelectaction() {
        unset($_POST['formAction']);
        $name = $_POST;
        if ($_POST['postForm'] == 'Certificate of Arrival') {
            $this->x = '1';
        }
        if ($_POST['postForm'] == 'Certificate of Departure') {
            $this->x = '2';
        }
        if ($_POST['postForm'] == 'Certificate of Stay') {
            $this->x = '3';
        }
    }

    /* ENDS HERE */


    /* Third Step : Fill the form */

    /* ENDS HERE */

    public function getDBdata($name) {


        $query = abroad_stayDB::getStudentInfo($name);


        foreach ($query as $key => $value) {
            $this->pageTpl->assign('stFirstName', $value['firstName']);
            $this->pageTpl->assign('stLastName', $value['familyName']);
            $this->pageTpl->assign('stGender', $value['sex'] > 0 ? 'Male' : 'Female');
            $this->pageTpl->assign('stDtBirh', $value['birthDate']);
            $this->pageTpl->assign('stPlBirh', $value['birthPlace']);
            $this->pageTpl->assign('stMatrDate', $value['tel']);
            $this->pageTpl->assign('stMatrNum', $value['email']);
            $this->pageTpl->assign('stMail', $value['email']);

            $query2 = abroad_stayDB::getCoordInfo($query[0]['hostCoordinatorId']);
            foreach ($query2 as $key => $value) {
                $this->pageTpl->assign('seCorName', $value['familyName'] . '&nbsp;' . $value['firstName']);
                $this->pageTpl->assign('seCorMail', $value['email']);
                $this->pageTpl->assign('seCorTel', $value['tel']);
                $this->pageTpl->assign('seCorFax', $value['fax']);
            }

            $query2 = abroad_stayDB::getCoordInfo($query[0]['homeCoordinatorId']);
            foreach ($query2 as $key => $value) {
                $this->pageTpl->assign('reCorName', $value['familyName'] . '&nbsp;' . $value['firstName']);
                $this->pageTpl->assign('reCorMail', $value['email']);
                $this->pageTpl->assign('reCorTel', $value['tel']);

                $this->pageTpl->assign('reCorFax', $value['fax']);
            }

            $query2 = abroad_stayDB::getInstInfo($query[0]['homeInstitutionId']);
            foreach ($query2 as $key => $value) {
                $this->pageTpl->assign('reInName', $value['instName']);
            }
            $query2 = abroad_stayDB::getInstInfo($query[0]['hostInstitutionId']);
            foreach ($query2 as $key => $value) {
                $this->pageTpl->assign('seInName', $value['instName']);
            }
        }
    }

    public function doSubmit() {
        $this->fillRules();
        $this->errors = validateFields($_POST, $this->rules);
        if (!empty($this->errors)) {
            $this->fields = $_POST;
        }
    }

}

?>
