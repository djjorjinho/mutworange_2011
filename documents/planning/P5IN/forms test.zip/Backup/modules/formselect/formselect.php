<?php

/*
 * @author: Van Assche Nathan
 */

class formselectController extends PlonkController {

    //create an array for all the views in the layout folder
    //for each element in this array you have to create a 'show' method
    //see doHome and doLoginsucces
    protected $views = array('main');

    //create an array for the actions
    //for each element in this array you have to create a 'do' method
    //see doLogin



    public function showmain() {




        //pageMeta is just for all the imports of the js files
        $this->mainTpl->assign('pageMeta', '<script src="core/js/jquery-1.5.1.min.js" type="text/javascript"></script>
        <script src="core/js/jquery.validationEngine-en.js" type="text/javascript" charset="utf-8"> </script>
        <script src="core/js/jquery.validationEngine.js" type="text/javascript" charset="utf-8"></script>');
        $this->mainTpl->assign('pageTitle', "Form Selector");
        //assign pageSpecific CSS
        $this->mainTpl->assign('pageCSS', '<link rel="stylesheet" href="core/css/validationEngine.jquery.css" type="text/css"/>');
        $this->pageTpl->assign('TrLink', 'index.php?module=trrec&view=trrec');



    }

}
