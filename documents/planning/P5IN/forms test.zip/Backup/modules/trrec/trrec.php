<?php

/*
 * @author: Van Assche Nathan
 */

class trrecController extends PlonkController {

    protected $views = array('actionSelect','vsended', 'select', 'main', 'success');
    protected $actions = array('selectuser', 'shit');
    private $errors = ''; // set the errors array to empty, by default

    public function showactionselect() {
        $this->mainTpl->assign('pageTitle', "Select Action");
        $this->mainTpl->assign('pageCSS', '<link rel="stylesheet" href="core/css/validationEngine.jquery.css" type="text/css"/>');
    }


    public function showvsended() {
        $this->mainTpl->assign('pageTitle', "Select Action");
        $this->mainTpl->assign('pageCSS', '<link rel="stylesheet" href="core/css/validationEngine.jquery.css" type="text/css"/>');
        
         //Generates Student List
        $studentsLName = trrecDB::getStudentRecords();
        $this->pageTpl->setIteration('iRecords');
        foreach ($studentsLName as $key => $value) {
            $this->pageTpl->assignIteration('records', '<tr><td> ' . $value['matrNum'] . '</td><td> ' . $value['name'] . '</td><td> ' . $value['lname'] . '</td><td><form  method="post"><input type="hidden" name="lol" value="' . $value['matrNum'] . '" /><input type="hidden" name="formAction" id="formLogin" value="doSelectUser" /><input class="nxtBtn" type="submit" value="Proceed"/></form></td></tr>');
            $this->pageTpl->refillIteration('iRecords');
        }
        $this->pageTpl->parseIteration('iRecords');
    
    }



    public function showselect() {
        $this->mainTpl->assign('pageMeta', '<script src="core/js/jquery-1.5.1.min.js" type="text/javascript"></script>
        <script src="core/js/jquery.validationEngine-en.js" type="text/javascript" charset="utf-8"> </script>
        <script src="core/js/jquery.validationEngine.js" type="text/javascript" charset="utf-8"></script>');
        $this->mainTpl->assign('pageTitle', "Trancip Of Records");
        $this->mainTpl->assign('pageCSS', '<link rel="stylesheet" href="core/css/validationEngine.jquery.css" type="text/css"/>');



        //Generates Student List
        $studentsLName = trrecDB::getStudentList();
        $this->pageTpl->setIteration('iStudentsList');
        foreach ($studentsLName as $key => $value) {
            $this->pageTpl->assignIteration('studentsList', '<tr><td> ' . $value['matrNum'] . '</td><td> ' . $value['name'] . '</td><td> ' . $value['lname'] . '</td><td><form  method="post"><input type="hidden" name="lol" value="' . $value['matrNum'] . '" /><input type="hidden" name="formAction" id="formLogin" value="doSelectUser" /><input class="nxtBtn" type="submit" value="Proceed"/></form></td></tr>');
            $this->pageTpl->refillIteration('iStudentsList');
        }
        $this->pageTpl->parseIteration('iStudentsList');
    }

    public function doSelectUser() {

        PlonkSession::set("seluser", $_POST["lol"]);
        //  PlonkCookie::set("seluser", $_POST["lol"], time()+60);
        //   setcookie("seluser", $_POST["lol"], time()+60);
        PlonkWebsite::redirect($_SERVER['PHP_SELF'] . '?' . PlonkWebsite::$moduleKey . '=trrec&' . PlonkWebsite::$viewKey . '=main');
    }

    public function showmain() {
        $this->mainTpl->assign('pageMeta', '<script src="core/js/jquery-1.5.1.min.js" type="text/javascript"></script>
        <script src="core/js/jquery.validationEngine-en.js" type="text/javascript" charset="utf-8"> </script>
        <script src="core/js/jquery.validationEngine.js" type="text/javascript" charset="utf-8"></script>');
        $this->pageTpl->assign('errorString', $this->errors);
        $this->mainTpl->assign('pageTitle', "Trancip Of Records");
        //assign pageSpecific CSS
        $this->mainTpl->assign('pageCSS', '<link rel="stylesheet" href="core/css/validationEngine.jquery.css" type="text/css"/>');
        $this->pageTpl->assign('value', '');
        $this->errors = null;
        $this->getDBdata();
    }

    public function getDBdata() {
        //$name = $_COOKIE["seluser"];
        $name = PlonkSession::get("seluser");

        $query = trrecDB::getStudentInfo($name);
        foreach ($query as $key => $value) {
            $this->pageTpl->assign('stFirstName', $value['name']);
            $this->pageTpl->assign('stLastName', $value['lname']);
            $this->pageTpl->assign('stGender', $value['gender']);
            $this->pageTpl->assign('stDtBirh', $value['birthday']);
            $this->pageTpl->assign('stPlBirh', $value['placeofbirth']);
            $this->pageTpl->assign('stMatrDate', $value['matrDate']);
            $this->pageTpl->assign('stMatrNum', $value['matrNum']);
            $this->pageTpl->assign('stMail', $value['stMail']);
            $this->pageTpl->assign('seInName', $value['seInName']);
            $this->pageTpl->assign('seCorDep', $value['seCorDep']);
            $this->pageTpl->assign('seCorName', $value['seCorName']);
            $this->pageTpl->assign('seCorMail', $value['seCorMail']);
            $this->pageTpl->assign('seCorTel', $value['seCorTel']);
            $this->pageTpl->assign('seCorFax', $value['seCorFax']);
            $this->pageTpl->assign('reInName', $value['reInName']);
            $this->pageTpl->assign('reCorDep', $value['reCorDep']);
            $this->pageTpl->assign('reCorName', $value['reCorName']);
            $this->pageTpl->assign('reCorMail', $value['reCorMail']);
            $this->pageTpl->assign('reCorTel', $value['reCorTel']);
            $this->pageTpl->assign('reCorFax', $value['reCorFax']);
        }
    }

    public function showsuccess() {

        //pageMeta is just for all the imports of the js files
        //assign pageSpecific CSS
    }

    public function doShit() {

        //$fields = array('stFirstName', 'stLastName');
        $i = 0;
        foreach ($_POST AS $key => $value) {
            $rules[] = "required," . $key . ", " . $key . " is required.";

            if (stristr($key, 'courseUnit') || stristr($key, 'corDur') || stristr($key, 'courseTitle') || stristr($key, 'locGrade') || stristr($key, 'ecGrade') || stristr($key, 'ectsGred')) {


                if ($value == '') {
                    echo is_int($value);
                }
            }
        }



        // PlonkFilter::getPostvalue('') replaces $_POST['']
        foreach ($_POST AS $key => $value) {
            $errors = validateFields($_POST, $rules);
        }


        if (count($errors) > 0) {
            $errorString = '<div style="  background: #f0d3d3; text-align: center; font-size: 14px; font-size: medium;"> ';
            $errorString .= '<p>There was an error processing the form.';
            $errorString .= '<br/>Please fill all fields marked with *</p>';
            $errorString .= '</div>';
            $errorString .= '<ul>';
            foreach ($errors as $error) {
                $errorString .= "<li>$error</li>";
            }
            $errorString .= '</ul>';

            // display the previous form */
            $this->errors = $errorString;
            //         $this->fields = $_POST;
        } else {




            trrecDB::formAp();
            PlonkWebsite::redirect($_SERVER['PHP_SELF'] . '?' . PlonkWebsite::$moduleKey . '=trrec&' . PlonkWebsite::$viewKey . '=success');
        }
    }

}

