<?php

class trrecDB {

    public static function formAp() {
        $db = PlonkWebsite::getDB();
        $name= $_POST['matrNum'];
        unset ($_POST['matrNum']);
        $at=serialize($_POST);
        $query="INSERT INTO TrRec_copy (matrNum, RECORDS) VALUES('$name', '$at') ";
        $db->execute($query);
    }


     public static function getDBdata(){

        $connect = mysql_connect(DB_HOST, DB_USER, DB_PASS) or die('Unable to connect to the database server at this time.');
        mysql_select_db("erasmus") or die(mysql_error());
        $name = 'Aggeliki';
        $result = mysql_query("SELECT * FROM TrRec where name ='$name'");
        $row = mysql_fetch_row($result);

        $subject = $row[1];
        echo "Name :$name <br>" .
        "Subject : $subject <br>";
        $this->pageTpl->assign("stFirstName", $row[0]);

    }


    //Get Values For Students List VIEW
    public static function getStudentRecords() {
        $db = PlonkWebsite::getDB();
        $stMatr = $db->retrieve("select matrNum from TrRec_copy");
$x='';
     foreach ($stMatr as $key => $value) {
 if (($value!="") && ($x!="")) {
             $x=$x." AND ";
            }
            if ($value == "") break;
          $x.=(string) "matrNum ='".$value['matrNum']."' ";
        
     }
            echo $x;
        $stName = $db->retrieve("select TrRec.matrNum,TrRec.name,TrRec.lname from TrRec where matrNum ='1611'   ");

        return $stName ;

    }



    //Get Values For Students List
    public static function getStudentList() {
        $db = PlonkWebsite::getDB();
        $stName = $db->retrieve("select matrNum,name,lname from TrRec");
        return $stName ;
        }


    //Get Info For Student
    public static function getStudentInfo($name) {
        $db = PlonkWebsite::getDB();
        $stInfo = $db->retrieve("SELECT * FROM TrRec where matrNum ='$name'");
        return $stInfo ;
        }
 
}

?>
