<?php

/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

class learnagr_chDB {

    public static function getStInfo($stId) {
        $db = PlonkWebsite::getDB();
        $stInfo = $db->retrieve("
               SELECT u.firstName,u.familyName,ins.instName,c.Name from users as u
               join institutions as ins on ins.instId=(SELECT hostInstitutionId from erasmusstudent where studentId='".$db->escape($stId)."')
               left join country as c on c.Code=ins.instCountry 
                where u.userId='".$db->escape($stId)."'");
        return $stInfo;
    }

//    public static function getInstCourses($stId) {
//        $db = PlonkWebsite::getDB();
//        $stInfo = $db->retrieve("
//               SELECT cour.courseCode,cour.courseId, cour.courseName, cour.ectsCredits from coursespereducperinst as cour
//               join educationperinstitute as ed on ed.educationPerInstId=cour.educationPerInstId
//               where cour.educationPerInstId=(SELECT ers.educationPerInstId from erasmusstudent as ers where ers.studentId='".$db->escape($stId)."')
//                   ");
//        return $stInfo;
//    }

    public static function getConfCourses($stId) {
        $db = PlonkWebsite::getDB();
        $stInfo = $db->retrieve("
               SELECT cour.courseCode, cour.courseName, cour.ectsCredits from coursespereducperinst as cour
               where cour.courseId='".$db->escape($stId)."'");
        return $stInfo;
    }

    public static function SubmitLearCh($form,$post) {
           $db = PlonkWebsite::getDB();
           $student=  PlonkSession::get('id');
        $instMail = $db->retrieve("SELECT inst.instEmail FROM institutions as inst where instId =(
            SELECT ers.hostInstitutionId FROM erasmusstudent as ers where ers.studentId='".$db->escape($student)."') ");
          
        
        $mail = new PHPMailer();
        $mail->IsSMTP();
        $mail->SMTPAuth = true;
        $mail->SMTPSecure = "tls";
        $mail->Host = "smtp.gmail.com";
        $mail->Port = 587;
        $mail->Username = "stvakis@gmail.com";
        $mail->Password = "";
        $mail->SetFrom('stvakis@gmail.com', 'Erasmus Line');
        $mail->FromName = "Erasmus Line";
        $mail->AddAddress($instMail[0]["instEmail"]);
        $mail->Subject = "Learning Agreement Change";
        $mail->Body = $form;
        $mail->IsHTML(true);
        $mail->SMTPDebug = false;
        $mail->do_debug = 0;
        if (!$mail->Send()) {
            return $mail->ErrorInfo;
            
        } else {
            
            /* Insert To table*/
        $db=  PlonkWebsite::getDB();
        $date=date("y-m-d");
        $post=  json_encode($post);
        $student=  PlonkSession::get('id');
        $query = "INSERT INTO forms (type,date,content,studentId) VALUES( 'LearnAgreementChange','".$db->escape($date)."','".$db->escape($post)."','".$db->escape($student)."') ";
        $db->execute($query);
            return '1';
        }
    }


/*testin*/
   public static function getRecords($userCours) {
        $db = PlonkWebsite::getDB();
        $stInfo = $db->retrieve("
                SELECT g.courseId 
                FROM grades as g
                where g.studentId ='".$db->escape($userCours)."'
                and g.localGrade>=(
                SELECT scale from institutions where instId=(
                select hostInstitutionId from erasmusstudent where studentId='".$db->escape($userCours)."'))");

        return $stInfo;
    }
    
    
        public static function getSucceedCourses($stId) {
        $db = PlonkWebsite::getDB();
        $stInfo = $db->retrieve("
               SELECT cour.courseCode,cour.courseId, cour.courseName, cour.ectsCredits from coursespereducperinst as cour
               join educationperinstitute as ed on ed.educationPerInstId=cour.educationPerInstId
               join grades as g on cour.courseId=g.courseId
               where cour.educationPerInstId=(SELECT ers.educationPerInstId from erasmusstudent as ers where ers.studentId='".$db->escape($stId)."')
               and g.localGrade>=(
                SELECT scale from institutions where instId=(
                select hostInstitutionId from erasmusstudent where studentId='".$db->escape($stId)."'))   ");
        return $stInfo;
    }
    
        public static function getSelectedCourses($stId) {
        $db = PlonkWebsite::getDB();
        $stInfo = $db->retrieve("
               SELECT cour.courseCode,cour.courseId, cour.courseName, cour.ectsCredits from coursespereducperinst as cour
               join educationperinstitute as ed on ed.educationPerInstId=cour.educationPerInstId
               right join grades as g on cour.courseId=g.courseId
               where cour.educationPerInstId=(SELECT ers.educationPerInstId from erasmusstudent as ers where ers.studentId='".$db->escape($stId)."')
               and g.localGrade is NULL");
        
        return $stInfo;
    }
            
    public static function getSelectCourses($stId) {
        $db = PlonkWebsite::getDB();
        $stInfo = $db->retrieve("
               SELECT cour.courseCode,cour.courseId, cour.courseName, cour.ectsCredits from coursespereducperinst as cour
               join educationperinstitute as ed on ed.educationPerInstId=cour.educationPerInstId
               where cour.educationPerInstId=(SELECT ers.educationPerInstId from erasmusstudent as ers where ers.studentId='".$db->escape($stId)."')
               and cour.courseId not in (select g.courseId from grades as g where 
               g.studentId='".$db->escape($stId)."')   ");
        return $stInfo;
    }
    
}
?>