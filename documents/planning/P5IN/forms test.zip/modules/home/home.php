<?php

/*
 * @author: Van Assche Nathan
 */

class HomeController extends PlonkController {

    //create an array for all the views in the layout folder
    //for each element in this array you have to create a 'show' method
    //see doHome and doLoginsucces
    protected $views = array('home');
    //create an array for the actions
    //for each element in this array you have to create a 'do' method
    //see doLogin
    protected $actions = array('login');

    public function showHome() {
        //pageMeta is just for all the imports of the js files
        $this->mainTpl->assign('pageMeta', '<script type="text/javascript" src=""></script>');
        //assign pageTitle 
        $this->mainTpl->assign('pageTitle', "Tutorial Plonk");
        //assign pageSpecific CSS
        $this->mainTpl->assign('pageCSS', '<link rel="stylesheet" type="text/css" media="screen" href="" />');
        //assign the variables
        $this->pageTpl->assign('msgEmail', '');
        $this->pageTpl->assign('msgPassword', '');
        $this->pageTpl->assign('Email', '');
        $this->pageTpl->assign('Password', '');

        //You can use the assignOption to show or to hide a part of the tpl
        $this->pageTpl->assignOption('showUsers');

        $this->mainTpl->logged='false';


        //use home.db.php
        $users = HomeDB::getUsers();
        //You can use Plonk::dump($users) to dump variables ( very useful for debugging!! )
        //Fill an iteration, here just put the text next to each other
        //but it is also possible to fill dropdownlists this way
        $this->pageTpl->setIteration('iUsers');
        foreach ($users as $key => $value) {
            $this->pageTpl->assignIteration('user', $value['Email']);
            $this->pageTpl->refillIteration('iUsers');
        }
        $this->pageTpl->parseIteration('iUsers');




    }

    public function doLogin() {

        // PlonkFilter::getPostvalue('') replaces $_POST['']
        if ((PlonkFilter::getPostValue('Email') == 'nathan.vanassche@kahosl.be') && (PlonkFilter::getPostValue('Password') == 'root')) {
            PlonkSession::set('id', '1613');
            //Create a session so we can use the email on the next page with the 'Email' key word
            //I have put this in comment because i haven't written any destroy function
            PlonkSession::set('Email', PlonkFilter::getPostValue('Email'));

            //redirect using PLONK
           PlonkWebsite::redirect($_SERVER['PHP_SELF'] . '?' . PlonkWebsite::$moduleKey . '=formselect&' . PlonkWebsite::$viewKey . '=main');

            
        }
    }

  

}

