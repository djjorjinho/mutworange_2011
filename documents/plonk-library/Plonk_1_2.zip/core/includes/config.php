<?php

/**
 * Config
 * ----------------------------------------------------------------
 */


	/**
	 * DEBUG
	 */
		define('DEBUG',			true);


/**
 * Config - Database Config
 * ----------------------------------------------------------------
 */

	/**
	 * Database Server Host
	 */
		define ('DB_HOST',		'localhost');


	/**
	 * Database Server Username
	 */
		define ('DB_USER',		'root');


	/**
	 * Database Server Password
	 */
		define ('DB_PASS',		'');


	/**
	 * Database Name
	 */
		define ('DB_NAME',		'erasmus');
                
        
        /**
        * Afzender
         */
                define('MAIL_SENDER','ErasmusLine@kahosl.be');
                
       /**
        * Smpt-server
        */
                define('MAIL_SMTP','smtp.kahosl.be');
       
       /**
        *Onderwerp
        */
                define('MAIL_SUBJECT','Task completed: ');
                
	
	
// EOF