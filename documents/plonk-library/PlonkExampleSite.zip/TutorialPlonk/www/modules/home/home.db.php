<?php

/*
 * @author: Van Assche Nathan
 */

class HomeDB {
    
    public static function getUsers() {
        //get DB instance
        //Name of the database, username and password are stored in config.php
        $db = PlonkWebsite::getDB();
        
        //query        
        $users = $db->retrieve("select Email from users");
        
        return $users;
    }

}

?>
