<?php

/**
 * Config
 * ----------------------------------------------------------------
 */


	/**
	 * DEBUG
	 */
		define('DEBUG', true);


/**
 * Config - Database Config
 * ----------------------------------------------------------------
 */

	/**
	 * Database Server Host
	 */
		define ('DB_HOST',		'localhost');


	/**
	 * Database Server Username
	 */
		define ('DB_USER',		'root');


	/**
	 * Database Server Password
	 */
		define ('DB_PASS',		'');


	/**
	 * Database Name
	 */
		define ('DB_NAME',		'mydb');
	
	
// EOF