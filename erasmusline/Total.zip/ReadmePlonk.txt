Just a small remark by the example site.
I guess the site won't work, because i wrote a 
sql query just as an example which uses my own database ..

